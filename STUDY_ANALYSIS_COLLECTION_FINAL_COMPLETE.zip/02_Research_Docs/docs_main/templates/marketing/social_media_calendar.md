# Social Media Calendar (Monthly)

| Date | Channel | Topic | Language | Media (Image/Video) | Notes |
|---|---|---|---|---|---|
| 2025-09-05 | Instagram | Sustainable electronics picks | DE | Carousel | Link to blog, UGC hashtag |
| 2025-09-07 | Facebook | Autumn home decor trends | FR | Image + short video | Boost €30 |
| 2025-09-10 | LinkedIn | EU supplier partnerships (OEM/ODM) | EN | Article share | Tag partners |
| 2025-09-12 | Instagram | Beauty bio guide | FR | Reel | CTA to category |
| 2025-09-15 | X | Launch deals reminder | ES | Image | Track with UTM |
| 2025-09-18 | TikTok | Quick unboxing: eco bundle | NL | Short video | Creator collab |

- Owner: social@eurodropship.local
- Approval: brand@eurodropship.local
- KPI: impressions (100k/mo), engagement_rate (≥ 3.0%), link_clicks (10k/mo)
