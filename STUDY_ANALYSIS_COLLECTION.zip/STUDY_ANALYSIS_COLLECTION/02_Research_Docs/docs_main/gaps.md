# Project Gaps (Rolling Log)

- Unit economics per supplier/product: detailed BOM and channel fees per market
- Finalized legal templates per market (localized Privacy/ToS/Returns)
- Marketing ops metrics: weekly dashboards per channel with targets and owners
- Supplier scoring matrix with evidence and periodic review cadence
- VAT/OSS mapping and invoice/records retention SOP
